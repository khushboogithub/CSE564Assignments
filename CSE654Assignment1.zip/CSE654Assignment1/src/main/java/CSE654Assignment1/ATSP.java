/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CSE654Assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Scanner;
import CSE654Assignment1.NNeigh;

/**
 *
 * @author khushboogupta
 */
public class ATSP {
    
    //this function eliminates wrapping in asymmetrical data.
    public static void assign(String prline, int[] disindex, double[][] distance, int dim){
            String spt=prline.trim();
            String sp[]=spt.split("\\s+");
            
            int spi=0;
            if(disindex[1]==dim){
                disindex[1]=0;
                disindex[0]++;
            }
                    
            while((disindex[1]<dim) && (spi<sp.length)){
                               
                distance[disindex[0]][disindex[1]]=Integer.parseInt(sp[spi]);                                        
                spi++;
                disindex[1]++;
            }
           
    }
    
    //this function calls assign() and read the asymmetrical data
    public static double[][] adjacencymatrix_atsp() throws FileNotFoundException, IOException 
    {
        int lineno=0,nol=0, eof = 0,dim=0;
        String filepath= System.getProperty("user.dir") + "/src/main/java/Data/rbg443.atsp";   
        LineNumberReader r = new LineNumberReader(new FileReader(filepath));
        String l;       
        while ((l = r.readLine()) != null) 
        {
            Scanner s = new Scanner(l);       
            while (s.hasNext()) {
                nol++;
                String data = s.nextLine();
                
                if(data.split("\\s")[0].equalsIgnoreCase("DIMENSION:")){
                    String[] sp = (data.split("\\s"));
                    dim=Integer.parseInt(sp[sp.length-1]);
                }
                if(data.equalsIgnoreCase("EDGE_WEIGHT_SECTION")){  
                    lineno=r.getLineNumber();
                }
                if(data.equalsIgnoreCase("EOF")){  
                    eof=r.getLineNumber();
                }                
            }            
        }
        double distance[][] = new double[dim][dim];
        int[] disindex={0,0};
        File text = new File(filepath);
        System.out.println("File Executed : " + text.getName());
        int presentline=0;
        Scanner s = new Scanner(text);       
            while (s.hasNext()) {
                String prline = s.nextLine();
                presentline++;
                if(presentline>lineno && presentline<eof)
                {                    
                    assign(prline,disindex,distance,dim);                   
                }                       
            }   
        return distance;
    }
    
   
    
    //calls the 2 functions : adjacencymatrix_atsp and the module NNeigh
    public static void main(String[] args) throws IOException{
        double[][] matrix=adjacencymatrix_atsp();
        int n=matrix.length;
        
        NNeigh.tsp_nn(matrix);        
                     
    }
    
}
