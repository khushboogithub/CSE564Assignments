/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CSE654Assignment1;

import java.io.IOException;
import java.util.Scanner;
import CSE654Assignment1.ATSP;
import CSE654Assignment1.TSP;

/**
 *
 * @author khushboogupta
 */

public class Main {


    public static void main(String[] args) throws IOException, InterruptedException {
        
        int ch;
        Scanner scan=new Scanner(System.in);
        
        System.out.println("Do you have a symmetric(0) or an asymmetric data(1)?");
        ch=scan.nextInt();
        if(ch==0){
            TSP.main(args);
        }
        else if(ch==1){
            ATSP.main(args);
        }
        else{
            System.out.println("Wrong input. Please try again. Symmetric-0/Asymmetric-1");
        }
    }
 }
    

